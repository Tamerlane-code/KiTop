# Varaq bot — ishga tushirish bo'yicha to'liq ko'rsatma

Bu bot Python tilida yozilgan va `python-telegram-bot` kutubxonasidan foydalanadi.
Quyidagi qadamlarni ketma-ket bajaring.

## 1-qadam: Bot tokenini olish

1. Telegram'da **@BotFather** ni toping va `/start` bosing
2. `/newbot` buyrug'ini yuboring
3. Botga ism bering (masalan: "Varaq kitob bot")
4. Foydalanuvchi nomi bering — oxiri `bot` bilan tugashi shart (masalan: `varaq_kitob_bot`)
5. BotFather sizga token beradi — bu shunga o'xshash ko'rinadi:
   `7234567890:AAH8x3kLp9-ZjQ2vN4tY6wXcRfDsEgHiJkL`
6. **Bu tokenni hech kimga ko'rsatmang** — bu sizning botingizga to'liq kirish huquqi

## 2-qadam: Serverga joylashtirish (deploy)

Dasturlash bilmasangiz, eng oson yo'l — **Railway.app** yoki **Render.com** kabi xizmatlar.
Ular bepul tarifda ham botni 24/7 ishlatish imkonini beradi.

### Railway orqali (tavsiya etiladi — eng sodda)

1. https://railway.app ga kiring, GitHub orqali ro'yxatdan o'ting
2. Bu loyihadagi barcha fayllarni (`bot.py`, `database.py`, `requirements.txt`) 
   yangi GitHub repozitoriyaga yuklang
3. Railway'da "New Project" → "Deploy from GitHub repo" tanlang
4. O'zingizning repozitoriyangizni tanlang
5. "Variables" bo'limida yangi o'zgaruvchi qo'shing:
   - Nomi: `BOT_TOKEN`
   - Qiymati: BotFather'dan olgan tokeningiz
6. Railway avtomatik botni ishga tushiradi

### Agar GitHub bilan ishlamagan bo'lsangiz

Bu qism uchun bir martalik yordam kerak bo'ladi — frilanser dasturchidan
"GitHub'ga loyiha yuklash va Railway'ga ulash" xizmatini so'rashingiz mumkin.
Bu odatda 30-60 daqiqalik ish, juda arzon (yoki tanishlaringizdan birortasi
bir o'tirishda yordam berishi mumkin).

## 3-qadam: Botni sinash

Serverga joylashtirilgandan so'ng:
1. Telegram'da o'z botingizni toping (foydalanuvchi nomi bo'yicha)
2. `/start` bosing — ro'yxatdan o'tish boshlanadi
3. `/qoshish` — kitob e'loni joylash
4. `/qidir` — kitoblarni qidirish
5. `/elonlarim` — o'z e'lonlaringizni ko'rish

## Joriy demo cheklovlari (bularni bilib qo'ying)

- **"Egasi bilan bog'lanish"** tugmasi hozircha faqat ism ko'rsatadi — 
  real xabar yuborish funksiyasi yo'q. Bu keyingi bosqichda qo'shiladi.
- **To'lov tizimi yo'q** — Click, Payme yoki Uzcard integratsiyasi
  alohida ishlab chiqilishi kerak.
- **Rasm yuklash yo'q** — hozircha faqat matn. Kitob muqovasi rasmini
  qo'shish keyingi versiyada qo'shilishi kerak.
- **Ma'lumotlar bazasi** — SQLite ishlatilgan, bu kichik boshlanish uchun
  yetarli (minglab foydalanuvchigacha), lekin katta o'sishda PostgreSQL'ga
  o'tish tavsiya etiladi.

## Keyingi qadamlar — qachon dasturchi yollash kerak

Quyidagilar uchun sizga albatta dasturchi kerak bo'ladi:
- To'lov tizimini ulash (Click/Payme)
- Rasm yuklash funksiyasi
- Real vaqtda xabar almashish (chat)
- Foydalanuvchi sonining ko'pligida xavfsizlik va tezlik optimallashtirish
- Veb-saytga o'tish bosqichi (Telegram bot + veb-sayt bir xil
  ma'lumotlar bazasidan foydalanishi mumkin — bu kod tuzilishi shunga
  moslashtirilgan)

## Savol tug'ilsa

Agar kod ichida biror joyni o'zgartirish kerak bo'lsa (masalan, yangi
hudud qo'shish, narx formatini o'zgartirish), menga aytsangiz — kerakli
qismni topib, tushuntirib, o'zgartirib beraman.
